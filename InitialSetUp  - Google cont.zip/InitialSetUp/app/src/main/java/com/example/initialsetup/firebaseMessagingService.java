package com.example.initialsetup;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import androidx.annotation.NonNull;

/*
 *new segment*
 * Note for sending the notification we need to use the token
 * Can do this using the database, tutorial I used did it using a realtime database, we can use a realtime database as well as a cloud firestore
 * Apparently the realtime database is decent for sending messages which I assume could be useful at a later stage in the scenario that Prof. Van Zyl wants a messaging system so you can:
 * Ask for files, say why you need a file and other such things
 * You will need to send messages to specific topic groups
 * If you don't receive a message check google play version, it might not be up-to date
 * You can have two emulators open at teh same time just to test and see if the broadcast works
 * Need to make specific updates
 *
 */

public class firebaseMessagingService extends FirebaseMessagingService {
    //used to receive incoming messages
    @Override
    public void onMessageReceived(@NonNull RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        //remoteMessage will contain our content so need to check that it actually has content
        //the remote message should come from firebase, I have done it this way incase we would like to have a system for messaging as well
        if(remoteMessage.getNotification() != null){

            String title = remoteMessage.getNotification().getTitle();
            String body = remoteMessage.getNotification().getBody();
            notificationHelper.displayNotification(getApplicationContext(), title, body);
            //Have defined this service in the android manifest
        }
    }
}
