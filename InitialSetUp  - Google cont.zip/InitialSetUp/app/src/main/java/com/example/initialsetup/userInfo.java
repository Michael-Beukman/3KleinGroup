package com.example.initialsetup;
import android.net.Uri;

/*
 *New Segment, created on 20/03/2020 incase useful.
 */

public class userInfo {
    String personName;
    String personGivenName;
    String personFamilyName;
    String personEmail;
    String personId;
    Uri personPhoto;
    String token = "";

    public userInfo(){
        this.personName = "";
        this.personGivenName = "";
        this.personFamilyName = "";
        this.personEmail = "";
        this.personId = "";
        this.personPhoto = null;
        this.token = "";
    }
    public void setPersonName(String name){
        this.personName = name;
    }
    public void setPersonGivenName(String givenName){
        this.personGivenName = givenName;
    }
    public void setPersonFamilyName(String familyName){
        this.personFamilyName = familyName;
    }
    public void setPersonEmail(String email){
        this.personEmail = email;
    }
    public void setPersonId(String id){
        this.personId = id;
    }
    public void setPersonPhoto(Uri info){
        this.personPhoto =  info;
    }
    public void setToken(String token) {
        this.token = token;
    }
    public String getPersonName(){
        return personName;
    }
    public String getPersonGivenName(){
        return  personGivenName;
    }
    public String getPersonFamilyName(){
        return personFamilyName;
    }
    public String getPersonEmail(){
        return personEmail;
    }
    public String getPersonId(){
        return personId;
    }
    public Uri getPersonPhoto(){
        return personPhoto;
    }
    public String getToken() {
        return token;
    }
}
