package com.example.initialsetup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentSender;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.UserHandle;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.messaging.FirebaseMessaging;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;

public class MainActivity extends AppCompatActivity {
    private SignInButton signInButton;
    private GoogleSignInClient mGoogleSignInClient;
    private  String TAG = "MainActivity";
    private FirebaseAuth mAuth;
    private Button btnSignOut;
    private String email = "mightyman770@gmail.com";
    private String emailPassword = "mightyman770M)";
    private int RC_SIGN_IN = 1;
    //Will be use to create notification channel (act as our constraints) 19/03/2020 10h00
    /*
        *new segment*
     */
    public static final String channelID = "tempNotification";
    public static final String channelName = "tempNotification Showcase";
    public static final String channelDesc = "shows the current temp notifications";
    //temp force notification button just to see the notification
    private Button forceNotify;

    public static userInfo user;
    /*Push notifications 19/03/2020 10h30 - struggling a bit with the firebase side of things since I cant seem to find this device
    Will cordon off the pieces that just need to be added to a version that is able to interact with Firebase properly
    Cordoned off places represented by the following as shown below take make it easier to tell what pieces
    /*
        *new segment*
     */
    /*
    Create new class to receive the notification - firebaseMessagingService
    Created a notification helper for easy ability to push notifications
    Create a way to open activities via pressing notification
        this will require appending intent
        just a token we pass to the application
        this allows another application to executed the defined code for that activity
     */


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*
         *new segment*
         */
        /*for android oreo and above need a notification channel created so will have it here
        Note O is oreo's code
        everytime the application is launched this if statement will be executed, it is okay since if a channel is created this won't do anything. */
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){

            //low means no sounds, each one does a different thing, some wont show the notifications
            NotificationChannel channel = new NotificationChannel(channelID, channelName, NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription(channelDesc);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
            // now this means the channel has been created
        }

        signInButton = findViewById(R.id.sign_in_button);
        btnSignOut = findViewById(R.id.sign_out_button);
        mAuth = FirebaseAuth.getInstance();


        /*
         *new segment* **CAUSES CRASH AT CURRENT HENCE THE TRY
         */
        //Will create the topic and subscribe to it, so whenever we send a notification to that specific topic, it will receive the update to that topic.
        //Just called it a temp topic, this currently causes a crash
        try {
            FirebaseMessaging.getInstance().subscribeToTopic("temp topic");
        }catch(Exception e){

            }

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        //On Click Listeners for buttons

        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signIn();
            }
        });

        btnSignOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mGoogleSignInClient.signOut();
                Toast.makeText(MainActivity.this,"You are Logged Out",Toast.LENGTH_SHORT).show();
                btnSignOut.setVisibility(View.INVISIBLE);
            }
        });

        /*
         *new segment*
         */
        //
        //forced notification just to allow you to force through a notification
        //note no variable types of notifications are here - i.e for different documents.
        //Have styled the notifications using the cloud messaging system in the notification Helper
        //This is just a local notification
        forceNotify = findViewById(R.id.notificationButton);
        forceNotify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayNotification("Pressed a button", "Button pressing caused a notification - noot noot");
            }
        });
        displayNotification("Hello", "Welcome");
    }

    private void signIn(){
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == RC_SIGN_IN){
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask){
        try{

            GoogleSignInAccount acc = completedTask.getResult(ApiException.class);
            Toast.makeText(MainActivity.this,"Signed In Successfully",Toast.LENGTH_SHORT).show();
            FirebaseGoogleAuth(acc);
        }
        catch (ApiException e){
            Toast.makeText(MainActivity.this,"Sign In Failed",Toast.LENGTH_SHORT).show();
            FirebaseGoogleAuth(null);
        }
    }

    private void FirebaseGoogleAuth(GoogleSignInAccount acct) {
        //check if the account is null
        if (acct != null) {
            AuthCredential authCredential = GoogleAuthProvider.getCredential(acct.getIdToken(), null);
            //careful of this for now, it will crash it
            //user.setToken(acct.getIdToken());
            mAuth.signInWithCredential(authCredential).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(MainActivity.this, "Successful", Toast.LENGTH_SHORT).show();
                        FirebaseUser user = mAuth.getCurrentUser();
                        updateUI(user);
                    } else {
                        Toast.makeText(MainActivity.this, "Failed", Toast.LENGTH_SHORT).show();
                        updateUI(null);
                    }
                }
            });
        }
        else{
            Toast.makeText(MainActivity.this, "acc failed", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateUI(FirebaseUser fUser){
        btnSignOut.setVisibility(View.VISIBLE);
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(getApplicationContext());
        if(account !=  null){
            String personName = account.getDisplayName();
            String personGivenName = account.getGivenName();
            String personFamilyName = account.getFamilyName();
            String personEmail = account.getEmail();
            String personId = account.getId();
            Uri personPhoto = account.getPhotoUrl();
            /*
            Beware uncommenting as the below actions seem to crash it
            user.setPersonEmail(personEmail);
            user.setPersonFamilyName(personFamilyName);
            user.setPersonGivenName(personGivenName);
            user.setPersonId(personId);
            user.setPersonPhoto(personPhoto);
            user.setPersonName(personName);
            */
            Toast.makeText(MainActivity.this,personName + personEmail ,Toast.LENGTH_SHORT).show();
        }

    }

    /*
     *new segment*
        * can delete when you desire, and rather use the notification helper alone.
     */
    //Notification builder
    private void displayNotification(String title, String content){
        /* ic notification is guys dino
        Priority refers to the notification's priority itself, currently left on default in case we want to have varying priorities */
        NotificationCompat.Builder noteBuilder = new NotificationCompat.Builder(this, channelID).setSmallIcon(R.drawable.ic_guydino).setContentTitle(title).setContentText(content).setPriority(NotificationCompat.PRIORITY_DEFAULT);
        //This completes the basic notification builder

        //Now to manage this notification system
        NotificationManagerCompat noteM = NotificationManagerCompat.from(this);
        /*requires the notification ID and this ID is used to update and delete the notifications but currently left this as one assuming we just want a basic notification
        Only have one notification at current(a basic one, we could have other ones should we want)*/
        noteM.notify(1, noteBuilder.build());
    }
    //Below added at 21h43 19/03/2020 and not working
    public static void displayIntentNotification(Context context, String notificationTitle, String notificationBody){

        //19/03/2020 21h20
        Intent intent = new Intent(context, profileActivity.class);
        //need to create a new intent and cancel the old intent we were on
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 100, intent, PendingIntent.FLAG_CANCEL_CURRENT);

        //just going to auto cancel for after you click on teh notification it will cancel.
        //Can send the notification from the firebase console
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, MainActivity.channelID).setSmallIcon(R.drawable.ic_guydino).setContentText(notificationTitle).setContentText(notificationBody).setContentIntent(pendingIntent).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_DEFAULT);
    }
}
