package com.example.initialsetup;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

/*
 *new segment*
 * class meant to contain a lot of general functionality however right now it is bulky and causing issues
 */

import androidx.core.app.NotificationCompat;

public class notificationHelper {

    public static void displayNotification(Context context, String notificationTitle, String notificationBody){

        /*
        Default priority used, therefore general, different priorities have different features as to what they do, feel free to change as needed

         */
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, MainActivity.channelID).setSmallIcon(R.drawable.ic_security).setContentText(notificationTitle).setContentText(notificationBody).setPriority(NotificationCompat.PRIORITY_DEFAULT);
    }
    public static void displayIntentNotification(Context context, String notificationTitle, String notificationBody){

        //19/03/2020 21h20
        Intent intent = new Intent(context, profileActivity.class);
        //need to create a new intent and cancel the old intent we were on
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 100, intent, PendingIntent.FLAG_CANCEL_CURRENT);

        //just going to auto cancel for after you click on teh notification it will cancel.
        //Can send the notification from the firebase console
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, MainActivity.channelID).setSmallIcon(R.drawable.ic_guydino).setContentText(notificationTitle).setContentText(notificationBody).setContentIntent(pendingIntent).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_DEFAULT);
    }
}
