package com.example.matthewcontent;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;

public class ProfileActivity extends AppCompatActivity {

    private FirebaseAuth userAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userAuth = FirebaseAuth.getInstance();

        FirebaseInstanceId.getInstance().getInstanceId().addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
            @Override
            public void onComplete(@NonNull Task<InstanceIdResult> task) {
                //Here we can get the registration token using the task
                //18/03/2020 having an issue with recieving this token unsure as to why.
                if (task.isSuccessful()) {
                    //Store this token in firebase
                    String token = task.getResult().getToken();
                    saveToken(token);

                } else {
                    //Shall display failing in the text view
                    //Currently having an issue receiving the token

                }
            }
        });
    }

    //19/03/2020 Morning
    private void saveToken(String token){
        String email = userAuth.getCurrentUser().getEmail();
        user user = new user(token, email);
        //users from the realtime data base.
        DatabaseReference databaseUser = FirebaseDatabase.getInstance().getReference("users");
        //Need a unique id, so use mAuth
        databaseUser.child(userAuth.getCurrentUser().getUid()).setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()){
                    Toast.makeText(ProfileActivity.this, "Token Saved", Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(ProfileActivity.this, "Failure to save token", Toast.LENGTH_LONG).show();
                }
            }
        });

    }
    @Override
    protected void onStart(){
        //based on the start profile activity from the main activity
        super.onStart();
        //If the current user is not logged in
        if(userAuth.getCurrentUser() == null) {
            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }
    }
}
