package com.example.matthewcontent;
//19/03/2020 morning
public class user {
    //Only two user values for now, storing the token in the profile activity for now
    public String email;
    public String token;

    //user constructor
    public user(String token, String email){
        this.token = token;
        this.email = email;
    }
}
