package com.example.matthewcontent;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;

public class MainActivity extends AppCompatActivity {


    //18/03/2020 - before implementation using Firebase
    /*Three things needed to get a notification working
        Need  a notification Channel
        Need a notification builder
        Need a notification manager*/

    /*18/03/2020 - after implementation using Firebase
    Using firebase need to be able to do push notifications to a specific device knowing all devices we have
    We need to do the following - identify a device that this is being sent to
    We can get the registration token to do that
    Therefore need the FCM which is the firebase registration token for this device

    **********************************************************************************
    *                                    PROBLEMS                                    *
    **********************************************************************************
    Currently the FCM generation is not working, when it is working things should continue as required
    The project is linked up to the KleinGroupV2 not sure if that is okay ?

     */

    /* Firebase authentication
        *** assumption here is that the registration token works, should that work the rest should, 'should' work ***
            Need to generate unique authentication IDs and store the authentication token in the backend

        Moving on to saving the token generated when registering with firebase
     */

    //Will be use to create notification channel (act as our constraints)
    private static final String channelID = "tempNotification";
    private static final String channelName = "tempNotification Showcase";
    private static final String channelDesc = "shows the current temp notifications";

    //From the FCM registration token
    private TextView FCMTextView;

    //From the login in using firebase - this is a generic email and username login
    private EditText editTextEmail, editTextPassword;
    private ProgressBar progressBar;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //During Login part use the login_form as  the immediate layout
        setContentView(R.layout.login_form);

        /*for android oreo and above need a notification channel created so will have it here
        Note O is oreo's code
        everytime the application is launched this if statement will be executed, it is okay since if a channel is created this won't do anything. */
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){

            //low means no sounds, each one does a different thing, some wont show the notifications
            NotificationChannel channel = new NotificationChannel(channelID, channelName, NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription(channelDesc);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
            // now this means the channel has been created
        }

        /*  ** FCM TOKEN **
        display the registration token
        first get the registration token have added the FCM to the app
        To circumvent this I have made the below a try for now rather than run it otherwise the app will crash
        */


       /* ***DEAD BLOCK THAT IS NOW IN PROFILE ACTIVITY ***
        try {
            FCMTextView = findViewById(R.id.fcmTextView);
            // ** MADE THE TEXT VIEW INVISIBLE ** - for fixing the token generation and seeing if it works later.

            FCMTextView.setVisibility(View.INVISIBLE);
            FirebaseInstanceId.getInstance().getInstanceId().addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                @Override
                public void onComplete(@NonNull Task<InstanceIdResult> task) {
                    //Here we can get the registration token using the task
                    //18/03/2020 having an issue with recieving this token unsure as to why.
                    if (task.isSuccessful()) {

                        String token = task.getResult().getToken();
                        FCMTextView.setText("Token : " + token);

                    } else {
                        //Shall display failing in the text view
                        //Currently having an issue receiving the token
                        FCMTextView.setText("Token not generated");

                    }
                }
            });
        }
        catch (Exception e){

        }
        */


        /*From here implementing the firebase authentication 19/03/2020
            ***NOTE ASSUMING THAT THE FCM WORKS***

         */

        progressBar = findViewById(R.id.progressBar);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        firebaseAuth = FirebaseAuth.getInstance();
        progressBar.setVisibility(View.INVISIBLE);

        findViewById(R.id.signUpBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Preforming either a login or a sign up, so let us first attempt to create a user in firebase
                createUser();
            }
        });


    }

    //Notification builder
    private void displayNotification(){
        /* ic notification is guys dino
        Priority refers to the notification's priority itself, currently left on default in case we want to have varying priorities */
        NotificationCompat.Builder noteBuilder = new NotificationCompat.Builder(this, channelID).setSmallIcon(R.drawable.ic_guydino).setContentTitle("notification title working").setContentText("notification message").setPriority(NotificationCompat.PRIORITY_DEFAULT);
        //This completes the basic notification builder

        //Now to manage this notification system
        NotificationManagerCompat noteM = NotificationManagerCompat.from(this);
        /*requires the notification ID and this ID is used to update and delete the notifications but currently left this as one assuming we just want a basic notification
        Only have one notification at current(a basic one, we could have other ones should we want)*/
        noteM.notify(1, noteBuilder.build());
    }

    //Function for firebase authentication - creating a user
    private void createUser(){
        final String email = editTextEmail.getText().toString().trim();
        final String password = editTextPassword.getText().toString().trim();

        //Quick Error checks in case either email or password is empty
        if (email.isEmpty()){
            editTextEmail.setError("An email must be entered");
            editTextEmail.requestFocus();
            return;
        }
        if(password.isEmpty()){
            editTextPassword.setError("A password must be entered");
            editTextPassword.requestFocus();
            return;
        }
        //
        if(password.length() < 6){
            editTextPassword.setError("A password must be at least 6 characters long");
            editTextPassword.requestFocus();
            return;
        }

        //if passed all the validations we will create a user in the firebase console
        //will be executed whether successful or not
        progressBar.setVisibility(View.VISIBLE);
        firebaseAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()) {
                    startProfileActivity();
                }
                //Case where the user exists already in the database
                else{
                    //User is already in our database
                    if(task.getException() instanceof FirebaseAuthUserCollisionException){
                        userLogin(email,password);
                    }
                    //Some problem
                    else{
                        progressBar.setVisibility(View.INVISIBLE);
                        Toast.makeText(MainActivity.this, task.getException().getMessage(),Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }

    //This is from the attempt to save the token for firebase 19/03/2020 morning
    @Override
    protected void onStart(){
        //based on the start profile activity from the main activity
        super.onStart();
        //If the current user is already logged in
        if(firebaseAuth.getCurrentUser() != null) {
            Toast.makeText(MainActivity.this, "Token Already Saved", Toast.LENGTH_LONG).show();
            startProfileActivity();
        }
    }

    //From the firebase auth
    private void startProfileActivity(){
        Intent intent = new Intent(this, ProfileActivity.class);
        //needs to be started as a fresh activity in case the user tries to go back and requires 2 flags
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }
    //From the firebase auth
    private void userLogin(String email, String password){
        firebaseAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    startProfileActivity();
                }
                else{
                    progressBar.setVisibility(View.INVISIBLE);
                    Toast.makeText(MainActivity.this, task.getException().getMessage(),Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
